
import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, deleteDoc, doc, updateDoc } from 'firebase/firestore'; // 🟢 Removed query/orderBy
import { MessageSquare, Trash2, CheckCircle, Clock, Inbox } from 'lucide-react';
import { Pagination } from './dashboard/Pagination';

export default function FeedbackInbox() {
    const [mensajes, setMensajes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 5;

    // Lógica de Paginación
    const totalItems = mensajes.length;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedMessages = mensajes.slice(startIndex, startIndex + itemsPerPage);

    useEffect(() => {
        // 📡 LEER SUGERENCIAS
        const unsubscribe = onSnapshot(collection(db, "sugerencias"),
            (snapshot) => {
                const rawData = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

                // 🟢 FILTRAR SOLO NO ARCHIVADOS
                const filteredData = rawData.filter(m => !m.archivado);

                // 🟢 CLIENT-SIDE SORTING
                const sortedData = filteredData.sort((a, b) => {
                    if (!a.fecha) return 1;
                    if (!b.fecha) return -1;
                    return b.fecha?.seconds - a.fecha?.seconds;
                });

                setMensajes(sortedData);
                setLoading(false);
            },
            (error) => {
                console.error("Error leyendo buzón:", error);
                setLoading(false);
            }
        );
        return () => unsubscribe();
    }, []);

    const marcarLeido = async (msg) => {
        try {
            if (msg.leido) {
                // 🟢 ARCHIVAR (No borrar)
                await updateDoc(doc(db, "sugerencias", msg.id), { archivado: true });
            } else {
                // Marcar
                await updateDoc(doc(db, "sugerencias", msg.id), { leido: true });
            }
        } catch (e) {
            console.error(e);
        }
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center p-20 text-slate-500 animate-pulse gap-4">
            <Inbox size={48} className="opacity-50" />
            <p className="font-mono text-sm tracking-widest">BUSCANDO CORRESPONDENCIA...</p>
        </div>
    );

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-8 border-b border-slate-700 pb-4">
                <MessageSquare className="text-amber-400" size={28} />
                <h2 className="text-2xl font-bold text-white tracking-tighter">BUZÓN DE USUARIOS</h2>
                <span className="bg-slate-800 text-slate-400 px-2 py-0.5 rounded text-xs font-mono">{mensajes.length} MENSAJES</span>
            </div>

            <div className="space-y-4">
                {mensajes.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-20 text-slate-600 gap-4">
                        <div className="bg-slate-900 p-6 rounded-full">
                            <Inbox size={48} />
                        </div>
                        <p className="italic">El buzón está vacío. Todo tranquilo. 🍃</p>
                    </div>
                )}

                {paginatedMessages.map(m => (
                    <div
                        key={m.id}
                        className={`
                        bg-slate-800 rounded-xl p-5 border transition-all hover:bg-slate-750 relative overflow-hidden group
                         ${m.leido ? 'border-slate-700 opacity-60 grayscale-[0.5]' : 'border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.1)]'}
                        `}
                    >
                        {/* DECORATION */}
                        {!m.leido && <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/10 rounded-bl-full pointer-events-none" />}

                        <div className="flex justify-between items-start mb-3 relative z-10">
                            <div className="flex items-center gap-3">
                                <div className={`w-2.5 h-2.5 rounded-full ${m.leido ? 'bg-slate-500' : 'bg-amber-500 animate-ping'}`} />
                                <h3 className={`text-lg font-bold ${m.leido ? 'text-slate-400' : 'text-slate-100'}`}>{m.title || 'Sin Asunto'}</h3>
                            </div>
                            <span className="text-xs text-slate-500 font-mono flex items-center gap-1 bg-slate-900/50 px-2 py-1 rounded">
                                <Clock size={12} />
                                {m.fecha?.toDate ? m.fecha.toDate().toLocaleString('es-VE') : 'Reciente'}
                            </span>
                        </div>

                        <p className="text-slate-300 text-sm leading-relaxed mb-4 bg-slate-900/30 p-4 rounded-lg border border-slate-700/30">
                            {m.message}
                        </p>

                        <div className="flex justify-between items-end text-xs text-slate-500 relative z-10">
                            <div className="flex flex-col gap-0.5">
                                <span className="uppercase tracking-widest font-black text-[10px] text-slate-400">ORIGEN</span>
                                <span className="font-bold text-slate-300 text-sm">{m.nombreNegocio || 'Anónimo'}</span>
                                <span className="font-mono text-[10px] opacity-70">{m.hardwareId} • {m.version}</span>
                            </div>

                            <button
                                onClick={() => marcarLeido(m)}
                                className={`
                                    flex items-center gap-2 px-4 py-2 rounded-lg font-bold tracking-wide transition-all
                                    ${m.leido
                                        ? 'bg-red-900/20 text-red-500 hover:bg-red-500 hover:text-white border border-red-900/30'
                                        : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/20'}
                                `}
                            >
                                {m.leido ? (
                                    <> <Trash2 size={16} /> ARCHIVAR </>
                                ) : (
                                    <> <CheckCircle size={16} /> MARCAR LEÍDO </>
                                )}
                            </button>
                        </div>
                    </div>
                ))}

                {/* Paginación */}
                <Pagination
                    currentPage={currentPage}
                    totalItems={totalItems}
                    itemsPerPage={itemsPerPage}
                    onPageChange={setCurrentPage}
                />
            </div>
        </div>
    );
}
